# Assignment 1

學生名稱：
SIU KA YAN
## 使用說明

1. **安裝程式庫**：

```bash
npm install
```

2. **執行測試**：

```bash
npm test
```
